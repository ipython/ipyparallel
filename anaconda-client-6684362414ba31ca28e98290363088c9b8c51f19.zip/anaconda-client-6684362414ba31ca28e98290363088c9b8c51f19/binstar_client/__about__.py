# -*- coding: utf-8 -*-

"""Details about package."""

__all__ = ['__version__']

__version__ = '1.11.0rc1'
