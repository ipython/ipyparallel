# pylint: disable=missing-module-docstring,missing-class-docstring,missing-function-docstring

import unittest
from binstar_client.utils.notebook import inflection


class InflectorsTestCase(unittest.TestCase):
    def test_one_directory(self):
        self.assertEqual(inflection.parameterize('Donald E. Knuth'), 'donald-e-knuth')


if __name__ == '__main__':
    unittest.main()
