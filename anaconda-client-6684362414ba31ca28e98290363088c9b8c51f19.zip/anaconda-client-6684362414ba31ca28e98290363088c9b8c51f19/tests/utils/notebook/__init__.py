# -*- coding: utf-8 -*-

"""Tests for :mod:`binstar_client.utils.notebook`."""
