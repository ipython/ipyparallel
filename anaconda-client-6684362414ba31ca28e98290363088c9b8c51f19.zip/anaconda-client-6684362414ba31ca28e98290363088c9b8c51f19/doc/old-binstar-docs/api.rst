
API
======


.. py:module:: binstar_client


.. autoclass:: Binstar
   :members:
