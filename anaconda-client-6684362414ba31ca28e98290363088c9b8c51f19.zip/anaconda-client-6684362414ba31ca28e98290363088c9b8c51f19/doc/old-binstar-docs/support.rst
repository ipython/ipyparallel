
Support
=======

The easiest way to get help is to open an issue on Github_. Alternatively you can send an email to support@anaconda.org.

.. _Github: https://github.com/Binstar/binstar_client/issues


