
FAQ
======


**What is Anaconda Cloud?**

Binstar is a complete package management solution. It allows you to launch your own private package hosting server and allows unlimited public packages.
