Windows
========

Windows versions of Binstar coming soon.