Binstar is now Anaconda Cloud!
==============================

Binstar is now Anaconda Cloud. Please see our current documentation: http://docs.anaconda.org/
